﻿<#
.SYNOPSIS
  Установщик APO SoundPad с откатом.

.DESCRIPTION
  Install   — копирует DLL в Program Files, регистрирует COM/APO, прописывает APO как endpoint-эффект
              выбранного МИКРОФОНА и перезапускает аудиослужбу. Любая ошибка на любом шаге -> автоматический откат
              всех уже сделанных шагов (реестр, права на ключ, файлы) и повторный запуск аудио.
  Uninstall — возвращает всё по манифесту (C:\ProgramData\SoundPad\Apo\manifest.json).
  List      — показывает микрофоны и их GUID.

  Запускать из PowerShell 64-bit ОТ ИМЕНИ АДМИНИСТРАТОРА.

.EXAMPLE
  .\Install-SoundPadApo.ps1 -Action List
  .\Install-SoundPadApo.ps1 -Action Install -EndpointId '{xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx}'
  .\Install-SoundPadApo.ps1 -Action Uninstall
#>
[CmdletBinding()]
param(
    [ValidateSet('Install', 'Uninstall', 'List')][string]$Action = 'Install',
    [string]$DllPath = (Join-Path (Get-Location).Path '..\SoundPadApo\bin\Release\SoundPadApo.dll'),
    # GUID микрофона (из -Action List) или полный ID вида {0.0.1.00000000}.{guid}
    [string]$EndpointId,
    # Какое значение FxProperties занять. ,7 = PKEY_FX_EndpointEffectClsid (эффект на весь микрофон после микширования).
    [string]$FxValueName = '{d04e05a6-594b-4fb6-a80d-01af5eed7d1d},7',
    [switch]$AllowUnsigned
)

$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------------ константы
$ApoClsid   = '{7E4B2A1C-5D3F-4A8B-9C6E-2F1A0B3D4E5F}'   # = CLSID_SoundPadApo в Guids.h
$ApoIfaceId = '{FD7F2B29-24D0-4B5C-B177-592C39F9CA10}'   # IAudioProcessingObject
$InstallDir = Join-Path $env:ProgramFiles 'SoundPad\Apo'
$DataDir    = Join-Path $env:ProgramData 'SoundPad\Apo'
$Manifest   = Join-Path $DataDir 'manifest.json'
$MMCapture  = 'SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Capture'
$LM         = [Microsoft.Win32.Registry]::LocalMachine
$RR         = [System.Security.AccessControl.RegistryRights]

# ------------------------------------------------------------------ привилегии (для ключей, которыми владеет TrustedInstaller)
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class SpPriv {
  [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr h, int acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool LookupPrivilegeValue(string sys, string name, out long luid);
  [DllImport("advapi32.dll", SetLastError=true)] static extern bool AdjustTokenPrivileges(IntPtr tok, bool dis, ref TP n, int len, IntPtr prev, IntPtr ret);
  [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
  [StructLayout(LayoutKind.Sequential, Pack=1)] struct TP { public int Count; public long Luid; public int Attr; }
  public static bool Enable(string name) {
    IntPtr tok; if (!OpenProcessToken(GetCurrentProcess(), 0x28, out tok)) return false;
    TP tp = new TP(); tp.Count = 1; tp.Attr = 2;
    if (!LookupPrivilegeValue(null, name, out tp.Luid)) return false;
    AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    return Marshal.GetLastWin32Error() == 0;
  }
}
"@

function Enable-Privileges {
    foreach ($p in 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege') { [void][SpPriv]::Enable($p) }
}

# ------------------------------------------------------------------ вспомогательное
function Write-Step([string]$t) { Write-Host "==> $t" -ForegroundColor Cyan }

function Assert-Environment {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Запусти PowerShell от имени администратора.'
    }
    if (-not [Environment]::Is64BitProcess) { throw 'Нужен 64-битный PowerShell (APO 64-битный).' }
}

function Get-CaptureEndpoints {
    $root = $LM.OpenSubKey($MMCapture)
    foreach ($n in $root.GetSubKeyNames()) {
        $k = $root.OpenSubKey($n)
        $state = $k.GetValue('DeviceState')
        $p = $k.OpenSubKey('Properties')
        $desc = $null; $name = $null
        if ($p) {
            $name = $p.GetValue('{b3f8fa53-0004-438e-9003-51a46e139bfc},6')
            $desc = $p.GetValue('{a45c254e-df1c-4efd-8020-67d146a850e0},2')
        }
        [pscustomobject]@{ Guid = $n; Active = ($state -eq 1); Name = "$desc ($name)" }
    }
}

function Resolve-Endpoint {
    if ($EndpointId) {
        $m = [regex]::Matches($EndpointId, '\{[0-9a-fA-F\-]{36}\}')
        if ($m.Count -eq 0) { throw "Не похоже на GUID микрофона: $EndpointId" }
        return $m[$m.Count - 1].Value.ToLower()
    }
    $list = @(Get-CaptureEndpoints | Where-Object Active)
    if ($list.Count -eq 0) { throw 'Активных микрофонов не найдено.' }
    for ($i = 0; $i -lt $list.Count; $i++) { Write-Host ("[{0}] {1}  {2}" -f $i, $list[$i].Name, $list[$i].Guid) }
    $idx = [int](Read-Host 'Номер микрофона')
    return $list[$idx].Guid.ToLower()
}

function Run-Reg([string[]]$a) {
    $p = Start-Process reg.exe -ArgumentList $a -Wait -PassThru -WindowStyle Hidden
    if ($p.ExitCode -ne 0) { throw "reg.exe $($a -join ' ') -> код $($p.ExitCode)" }
}

function Save-Snapshot([string]$sub, [string]$file) {
    $k = $LM.OpenSubKey($sub)
    if ($null -eq $k) { return $false }
    $k.Dispose()
    Run-Reg @('export', "HKLM\$sub", $file, '/y')
    return $true
}

function Restore-Key([string]$sub, [string]$snapshotFile) {
    $LM.DeleteSubKeyTree($sub, $false)
    if ($snapshotFile -and (Test-Path $snapshotFile)) { Run-Reg @('import', $snapshotFile) }
}

function Get-Sddl([string]$sub) {
    $k = $LM.OpenSubKey($sub, 'ReadSubTree', $RR::ReadPermissions)
    try { $k.GetAccessControl().GetSecurityDescriptorSddlForm('Owner,Group,Access') } finally { $k.Dispose() }
}

# Даёт Администраторам полный доступ к ключу (по умолчанию им владеет TrustedInstaller).
function Unlock-Key([string]$sub) {
    Enable-Privileges
    $k = $LM.OpenSubKey($sub, 'ReadWriteSubTree', $RR::TakeOwnership)
    $acl = New-Object System.Security.AccessControl.RegistrySecurity
    $acl.SetOwner((New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-32-544'))
    $k.SetAccessControl($acl); $k.Dispose()

    $k = $LM.OpenSubKey($sub, 'ReadWriteSubTree', ($RR::ReadPermissions -bor $RR::ChangePermissions))
    $acl = $k.GetAccessControl()
    $rule = New-Object System.Security.AccessControl.RegistryAccessRule((New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-32-544'), 'FullControl', 'ContainerInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
    $k.SetAccessControl($acl); $k.Dispose()
}

# Возвращает исходные владельца и права ключа (SDDL).
function Restore-Acl([string]$sub, [string]$sddl) {
    Enable-Privileges
    $k = $LM.OpenSubKey($sub, 'ReadWriteSubTree', ($RR::ChangePermissions -bor $RR::TakeOwnership))
    $acl = New-Object System.Security.AccessControl.RegistrySecurity
    $acl.SetSecurityDescriptorSddlForm($sddl)
    $k.SetAccessControl($acl); $k.Dispose()
}

function Restore-FxValue([string]$sub, [string]$name, $existed, $kind, $value) {
    $k = $LM.OpenSubKey($sub, $true)
    try {
        if ($existed) {
            if ($kind -eq 'Binary') { $value = [byte[]]$value }
            $k.SetValue($name, $value, [Microsoft.Win32.RegistryValueKind]$kind)
        } else { $k.DeleteValue($name, $false) }
    } finally { $k.Dispose() }
}

function Stop-Audio {
    Stop-Service Audiosrv -Force -ErrorAction SilentlyContinue
    Stop-Service AudioEndpointBuilder -Force -ErrorAction SilentlyContinue
}
function Start-Audio {
    Start-Service AudioEndpointBuilder
    Start-Service Audiosrv
}

# ------------------------------------------------------------------ откат
# Журнал отката: стек записей @{ Fn = 'имя функции'; Args = @(аргументы) }. Выполняется в обратном порядке.
# (Не scriptblock'и с GetNewClosure: они теряют доступ к функциям скрипта.)
$script:Undo = New-Object System.Collections.Generic.Stack[object]
function Push-Undo([string]$fn, [object[]]$fnArgs) { $script:Undo.Push(@{ Fn = $fn; Args = $fnArgs }) }
function Remove-Dir([string]$path) { if (Test-Path $path) { Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue } }
function Invoke-Rollback {
    Write-Warning 'Откатываю изменения...'
    while ($script:Undo.Count -gt 0) {
        $a = $script:Undo.Pop()
        $fnArgs = @($a.Args)
        try { & $a.Fn @fnArgs } catch { Write-Warning "Шаг отката не удался: $($_.Exception.Message)" }
    }
}

# ------------------------------------------------------------------ Uninstall
function Invoke-Uninstall {
    if (-not (Test-Path $Manifest)) { Write-Host 'Установленного APO не найдено (нет манифеста).'; return }
    $m = Get-Content $Manifest -Raw | ConvertFrom-Json
    Write-Step 'Останавливаю аудиослужбу'
    Stop-Audio
    try {
        Write-Step 'Возвращаю настройки микрофона'
        $fx = "$MMCapture\$($m.EndpointGuid)\FxProperties"
        if ($LM.OpenSubKey($fx)) {
            Unlock-Key $fx
            Restore-FxValue $fx $m.FxValueName $m.PrevExisted $m.PrevKind $m.PrevValue
            Restore-Acl $fx $m.OrigSddl
        }
        Write-Step 'Удаляю регистрацию APO'
        Restore-Key "SOFTWARE\Classes\CLSID\$($m.Clsid)" $m.ClsidSnapshot
        Restore-Key "SOFTWARE\Classes\AudioEngine\AudioProcessingObjects\$($m.Clsid)" $m.EngineSnapshot
        Write-Step 'Удаляю файлы'
        if (Test-Path $m.InstallDir) { Remove-Item $m.InstallDir -Recurse -Force }
        Remove-Item $Manifest -Force
    } finally {
        Start-Audio
    }
    Write-Host 'APO удалён, исходные настройки возвращены.' -ForegroundColor Green
}

# ------------------------------------------------------------------ Install
function Invoke-Install {
    if (-not (Test-Path $DllPath)) { throw "Не найден $DllPath. Сначала собери проект SoundPadApo (Release|x64)." }
    $DllPath = (Resolve-Path $DllPath).Path

    # Подпись: для не-тестового режима Windows нужна валидная подпись; в тестовом режиме — тестовая.
    $sig = Get-AuthenticodeSignature $DllPath
    if ($sig.Status -ne 'Valid') {
        $bc = (& bcdedit /enum '{current}') -join "`n"
        $testMode = $bc -match 'testsigning\s+Yes'
        if (-not $testMode -and -not $AllowUnsigned) {
            throw "DLL не подписана (статус: $($sig.Status)), а тестовый режим Windows выключен. Подпиши (Sign-SoundPadApo.ps1) или включи 'bcdedit /set testsigning on' + перезагрузка. Для принудительной установки: -AllowUnsigned."
        }
        Write-Warning "Подпись: $($sig.Status). Продолжаю (тестовый режим / -AllowUnsigned)."
    }

    if (Test-Path $Manifest) { Write-Step 'Найдена прошлая установка — удаляю'; Invoke-Uninstall }

    $guid = Resolve-Endpoint
    $fxSub = "$MMCapture\$guid\FxProperties"
    if ($null -eq $LM.OpenSubKey($fxSub)) { throw "У микрофона $guid нет раздела FxProperties." }

    New-Item -ItemType Directory -Force $DataDir | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = Join-Path $DataDir "backup-$stamp"
    New-Item -ItemType Directory -Force $backup | Out-Null

    try { Checkpoint-Computer -Description 'SoundPad APO' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop; Write-Host 'Точка восстановления создана.' }
    catch { Write-Warning "Точку восстановления создать не удалось (это не критично): $($_.Exception.Message)" }

    $clsidSub   = "SOFTWARE\Classes\CLSID\$ApoClsid"
    $engineSub  = "SOFTWARE\Classes\AudioEngine\AudioProcessingObjects\$ApoClsid"
    $clsidSnap  = Join-Path $backup 'clsid.reg'
    $engineSnap = Join-Path $backup 'engine.reg'
    $origSddl   = Get-Sddl $fxSub

    # Прежнее значение, которое мы перезапишем
    $k = $LM.OpenSubKey($fxSub)
    $prevExisted = $null -ne $k.GetValue($FxValueName, $null)
    $prevKind = $null; $prevValue = $null
    if ($prevExisted) {
        $prevKind = $k.GetValueKind($FxValueName).ToString()
        $prevValue = $k.GetValue($FxValueName, $null, 'DoNotExpandEnvironmentNames')
    }
    $k.Dispose()

    try {
        Write-Step 'Останавливаю аудиослужбу'
        Stop-Audio
        Push-Undo 'Start-Audio' @()

        Write-Step 'Копирую файлы'
        $dllExisted = Test-Path $InstallDir
        New-Item -ItemType Directory -Force $InstallDir | Out-Null
        $target = Join-Path $InstallDir 'SoundPadApo.dll'
        Copy-Item $DllPath $target -Force
        if (-not $dllExisted) { Push-Undo 'Remove-Dir' @($InstallDir) }

        Write-Step 'Регистрирую COM-класс'
        $hasClsid = Save-Snapshot $clsidSub $clsidSnap
        Push-Undo 'Restore-Key' @($clsidSub, $(if ($hasClsid) { $clsidSnap } else { '' }))
        $key = $LM.CreateSubKey($clsidSub);  $key.SetValue('', 'SoundPad Mic Mixer'); $key.Dispose()
        $key = $LM.CreateSubKey("$clsidSub\InprocServer32")
        $key.SetValue('', $target); $key.SetValue('ThreadingModel', 'Both'); $key.Dispose()

        Write-Step 'Регистрирую APO в аудиодвижке'
        $hasEngine = Save-Snapshot $engineSub $engineSnap
        Push-Undo 'Restore-Key' @($engineSub, $(if ($hasEngine) { $engineSnap } else { '' }))
        $key = $LM.CreateSubKey($engineSub)
        $key.SetValue('FriendlyName', 'SoundPad Mic Mixer')
        $key.SetValue('Copyright', 'SoundPad')
        $key.SetValue('MajorVersion', 1, 'DWord');  $key.SetValue('MinorVersion', 0, 'DWord')
        $key.SetValue('Flags', 15, 'DWord')                      # APO_FLAG_DEFAULT
        $key.SetValue('MinInputConnections', 1, 'DWord');  $key.SetValue('MaxInputConnections', 1, 'DWord')
        $key.SetValue('MinOutputConnections', 1, 'DWord'); $key.SetValue('MaxOutputConnections', 1, 'DWord')
        $key.SetValue('MaxInstances', -1, 'DWord')               # 0xFFFFFFFF
        $key.SetValue('NumAPOInterfaces', 1, 'DWord')
        $key.SetValue('APOInterface0', $ApoIfaceId)
        $key.Dispose()

        Write-Step "Подключаю APO к микрофону $guid"
        Unlock-Key $fxSub
        Push-Undo 'Restore-Acl' @($fxSub, $origSddl)
        Push-Undo 'Restore-FxValue' @($fxSub, $FxValueName, $prevExisted, $prevKind, $prevValue)
        $key = $LM.OpenSubKey($fxSub, $true)
        $key.SetValue($FxValueName, $ApoClsid, 'String')
        $back = $key.GetValue($FxValueName); $key.Dispose()
        if ($back -ne $ApoClsid) { throw 'Значение в FxProperties не записалось.' }

        Write-Step 'Запускаю аудиослужбу'
        Start-Audio
        Start-Sleep -Seconds 2
        if ((Get-Service Audiosrv).Status -ne 'Running') { throw 'Аудиослужба не запустилась после установки.' }

        $manifest = [ordered]@{
            Version = 1; Installed = (Get-Date).ToString('s'); Clsid = $ApoClsid; InstallDir = $InstallDir
            EndpointGuid = $guid; FxValueName = $FxValueName
            PrevExisted = $prevExisted; PrevKind = $prevKind; PrevValue = $prevValue
            OrigSddl = $origSddl
            ClsidSnapshot = $(if ($hasClsid) { $clsidSnap } else { $null })
            EngineSnapshot = $(if ($hasEngine) { $engineSnap } else { $null })
        }
        $manifest | ConvertTo-Json -Depth 4 | Set-Content $Manifest -Encoding UTF8
    }
    catch {
        $err = $_
        Invoke-Rollback
        try { if ((Get-Service Audiosrv).Status -ne 'Running') { Start-Audio } } catch { }
        throw "Установка не удалась, изменения откатаны. Причина: $($err.Exception.Message)"
    }

    Write-Host ''
    Write-Host 'Готово. В SoundPad выбери режим APO (ApoSink) для этого микрофона и запусти микс.' -ForegroundColor Green
    Write-Host "Удалить: .\Install-SoundPadApo.ps1 -Action Uninstall"
}

# ------------------------------------------------------------------ main
switch ($Action) {
    'List'      { Get-CaptureEndpoints | Format-Table Active, Guid, Name -AutoSize }
    'Install'   { Assert-Environment; Invoke-Install }
    'Uninstall' { Assert-Environment; Invoke-Uninstall }
}

